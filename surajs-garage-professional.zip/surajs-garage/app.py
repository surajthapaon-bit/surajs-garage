"""Suraj's Garage — application entry point."""
from __future__ import annotations

import runpy

import streamlit as st

from auth import require_login
from config import CONFIG, inject_theme
from db import init_db

st.set_page_config(
    page_title=f"{CONFIG.name} — {CONFIG.subtitle}",
    page_icon="🔧",
    layout="wide",
    initial_sidebar_state="expanded",
)

init_db()
inject_theme()

name, username, auth = require_login()
st.session_state["username"] = username
st.session_state["display_name"] = name

# ---------------------------------------------------------------- sidebar
with st.sidebar:
    st.markdown(f'<div class="sg-brand">{CONFIG.name}</div>', unsafe_allow_html=True)
    st.markdown(f'<div class="sg-sub">{CONFIG.subtitle}</div>', unsafe_allow_html=True)
    st.write("")

    if st.button("＋  New diagnostic case", use_container_width=True, type="primary"):
        st.session_state["nav"] = "Cases"
        st.session_state["_open_new_case"] = True
        st.rerun()

    st.write("")
    nav = st.radio(
        "Navigate",
        [
            "Dashboard",
            "Vehicles",
            "Cases",
            "Case workspace",
            "Case library",
            "Report builder",
            "Search",
            "Settings",
        ],
        label_visibility="collapsed",
        key="nav",
    )

    st.write("")
    st.divider()
    st.caption(f"Signed in as **{name}**")
    auth.logout(location="sidebar", button_name="Sign out", key="logout_widget")

# ---------------------------------------------------------------- routing
ROUTES = {
    "Dashboard":       "views/dashboard.py",
    "Vehicles":        "views/vehicles.py",
    "Cases":           "views/cases.py",
    "Case workspace":  "views/case_workspace.py",
    "Case library":    "views/case_library.py",
    "Report builder":  "views/report_builder.py",
    "Search":          "views/search.py",
    "Settings":        "views/settings.py",
}

target = ROUTES.get(nav, "views/dashboard.py")
runpy.run_path(target, run_name="__page__")
