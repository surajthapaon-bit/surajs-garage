"""Settings — backup, export, template management."""
from __future__ import annotations

import json
from datetime import datetime, timezone

import streamlit as st

from config import BACKUPS_DIR, CONFIG
from db import (
    Attachment, DiagnosticCase, DTC, GeneratedReport, Hypothesis,
    MaintenanceRecord, Measurement, Repair, Test, TimelineEvent, Vehicle,
    session_scope,
)
from services import list_templates

username = st.session_state["username"]
st.markdown("### Settings")

st.markdown(f"**Garage name:** {CONFIG.name}")
st.markdown(f"**Subtitle:** {CONFIG.subtitle}")
st.markdown(f"**Technician:** {CONFIG.technician}")
st.markdown(f"**Case prefix:** {CONFIG.case_prefix}")
st.markdown(f"**Units:** {CONFIG.mileage_unit} · {CONFIG.temperature_unit}")
st.caption("Edit `config.py` to change branding and defaults.")

st.divider()
st.markdown("#### Backup / Export")

def _dump_all() -> dict:
    with session_scope() as s:
        veh = list(s.query(Vehicle).filter(Vehicle.owner == username))
        vids = [v.id for v in veh]
        cases = list(s.query(DiagnosticCase).filter(DiagnosticCase.vehicle_id.in_(vids))) if vids else []
        cids = [c.id for c in cases]

        def rd(table, cond):
            return [dict(row.__dict__) for row in s.query(table).filter(cond).all()
                    if not row.__dict__.get("_sa_instance_state")]

        def clean(rows):
            for r in rows:
                for k in list(r.keys()):
                    if isinstance(r[k], datetime):
                        r[k] = r[k].isoformat()
                    if k.startswith("_"):
                        r.pop(k)
            return rows

        return {
            "exported_at": datetime.now(timezone.utc).isoformat(),
            "garage": CONFIG.name,
            "vehicles": clean(rd(Vehicle, Vehicle.owner == username)),
            "cases": clean(rd(DiagnosticCase, DiagnosticCase.vehicle_id.in_(vids))) if vids else [],
            "tests": clean(rd(Test, Test.case_id.in_(cids))) if cids else [],
            "measurements": clean(rd(Measurement, Measurement.case_id.in_(cids))) if cids else [],
            "dtcs": clean(rd(DTC, DTC.case_id.in_(cids))) if cids else [],
            "hypotheses": clean(rd(Hypothesis, Hypothesis.case_id.in_(cids))) if cids else [],
            "events": clean(rd(TimelineEvent, TimelineEvent.case_id.in_(cids))) if cids else [],
            "repairs": clean(rd(Repair, Repair.case_id.in_(cids))) if cids else [],
            "attachments": clean(rd(Attachment, Attachment.case_id.in_(cids))) if cids else [],
            "reports": clean(rd(GeneratedReport, GeneratedReport.case_id.in_(cids))) if cids else [],
            "maintenance": clean(rd(MaintenanceRecord, MaintenanceRecord.vehicle_id.in_(vids))) if vids else [],
        }

if st.button("Build full backup (JSON)", type="primary"):
    data = _dump_all()
    BACKUPS_DIR.mkdir(exist_ok=True)
    p = BACKUPS_DIR / f"backup_{datetime.now(timezone.utc):%Y%m%d_%H%M%S}.json"
    p.write_text(json.dumps(data, indent=2, default=str))
    st.success(f"Backup written: {p.name}")
    st.download_button("⬇  Download backup", data=p.read_text(),
                       file_name=p.name, mime="application/json")

st.divider()
st.markdown("#### Report templates")
templates = list_templates(username)
if not templates:
    st.caption("No saved templates yet. Built-in templates are always available in the Report Builder.")
else:
    for t in templates:
        st.markdown(f"**{t.name}** ({t.audience}) — {len(t.sections)} sections")

st.divider()
st.markdown("#### About")
st.caption(f"{CONFIG.name} — {CONFIG.subtitle}")
st.caption(f"Document version {CONFIG.doc_version}")
